/******************************************************************************
 *  Compilation:  javac Checkerboard.java
 *  Execution:    java Checkerboard
 *
 ******************************************************************************/

public class Checkerboard {

    public static void main(String[] args) {
        // javac -cp ".lift/*" .\Checkerboard.java
        // java -cp "./;./.lift/stdlib.jar" Checkerboard
        int n = Integer.parseInt(args[0]);
        int k = 0;
        StdDraw.setScale(0, n);
        for (int i = 0; i < n; ++i)
          for (int j = 0; j < n; ++j) {
            if ((i + j) % 2 == 0)
              StdDraw.setPenColor(StdDraw.BLUE);
            else
              StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
            //System.out.println(StdDraw.getPenColor());
            StdDraw.filledSquare(i+0.5, j+0.5, 0.5);
          }
   }

}