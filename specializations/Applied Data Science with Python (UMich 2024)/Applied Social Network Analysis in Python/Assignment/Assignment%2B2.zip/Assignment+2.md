
---

_You are currently looking at **version 1.1** of this notebook. To download notebooks and datafiles, as well as get help on Jupyter notebooks in the Coursera platform, visit the [Jupyter Notebook FAQ](https://www.coursera.org/learn/python-social-network-analysis/resources/yPcBs) course resource._

---

# Assignment 2 - Network Connectivity

In this assignment you will go through the process of importing and analyzing an internal email communication network between employees of a mid-sized manufacturing company. 
Each node represents an employee and each directed edge between two nodes represents an individual email. The left node represents the sender and the right node represents the recipient.


```python
import networkx as nx
%matplotlib inline
# This line must be commented out when submitting to the autograder
#!head email_network.txt
```

### Question 1

Using networkx, load up the directed multigraph from `email_network.txt`. Make sure the node names are strings.

*This function should return a directed multigraph networkx graph.*


```python
from graphviz import Digraph
from collections import defaultdict      
import matplotlib.pylab as plt
def answer_one():
    
    # Your Code Here
    input = open("C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\email_network.txt", "r")
    lines =  input.read().splitlines()
    G = nx.MultiDiGraph()
    #s = Digraph('emailnet', node_attr={'shape': 'plaintext'}, format='png',engine='sfdp') #,engine='circo') #engine='neato')
    #s.attr('node', style='filled', color='lightblue2', shape='circle')
    #s.attr('edge', color='bisque1')
    edict = defaultdict(int)
    for line in lines[1:]:
        A, B, _ = line.split('\t')
        #print(A,B)
        G.add_edge(A,B)
        #for e in G.edges():
        edict[A,B] += 1
    print(len(edict))    
    for e in edict:    
        (A, B) = e
        #s.node(str(A))
        #s.node(str(B))
        #s.edge(str(A), str(B), label=str(edict[e]))
    #s.render('C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails', view=False)
    return G # Your Answer Here
G = answer_one()
```

    5784
    


```python
d = max([G.degree(n) for n in G.nodes()])
plt.figure(figsize=(15,15))
nx.draw_spring(G,  
                 node_color = [(0, G.degree(n)/float(d), G.degree(n)/float(d)) for n in G.nodes()], 
                 with_labels = True, 
                 node_size = [5000*G.degree(n)/float(d) for n in G.nodes()],
                 edge_color='lightgray')
```


![png](output_5_0.png)



```python
plt.figure(figsize=(15,15))
nx.draw_random(G, 
                 node_color = [(G.degree(n)/float(d), G.degree(n)/float(d), 0) for n in G.nodes()], 
                 with_labels = True, 
                 node_size = [5000*G.degree(n)/float(d) for n in G.nodes()],
                 edge_color='lightgray')
```


![png](output_6_0.png)



```python
from IPython.display import Image
Image(filename='C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails.png')#,width=200, height=2000)
```




![png](output_7_0.png)



### Question 2

How many employees and emails are represented in the graph from Question 1?

*This function should return a tuple (#employees, #emails).*


```python
def answer_two():
        
    # Your Code Here
    G = answer_one()
    return (len(G.nodes()), len(G.edges())) # Your Answer Here
answer_two()
```

    5784
    




    (167, 82927)



### Question 3

* Part 1. Assume that information in this company can only be exchanged through email.

    When an employee sends an email to another employee, a communication channel has been created, allowing the sender to provide information to the receiver, but not vice versa. 

    Based on the emails sent in the data, is it possible for information to go from every employee to every other employee?


* Part 2. Now assume that a communication channel established by an email allows information to be exchanged both ways. 

    Based on the emails sent in the data, is it possible for information to go from every employee to every other employee?


*This function should return a tuple of bools (part1, part2).*


```python
def answer_three():
        
    # Your Code Here
    G = answer_one()
    return (nx.is_strongly_connected(G), nx.is_weakly_connected(G)) # Your Answer Here
answer_three()
```

    5784
    




    (False, True)



### Question 4

How many nodes are in the largest (in terms of nodes) weakly connected component?

*This function should return an int.*


```python
def answer_four():
        
    # Your Code Here
    G = answer_one()
    # nx.number_weakly_connected_components(G)
    return len(sorted(nx.weakly_connected_components(G))[0]) # Your Answer Here
answer_four()
```

    5784
    




    167




```python
from random import random
G = answer_one()
d = max([G.degree(n) for n in G.nodes()])
components = sorted(nx.strongly_connected_components(G))
#pal = [(random(), random(), random()) for _ in range(len(components)+1)]
#colors = [(0,0,0) for _ in range(len(G.nodes())+1)]
#print(len(colors), len(components))
#for i in range(len(components)):
#    for n in components[i]:
#        colors[int(n)] = pal[i]
_, i = max([(len(components[i]), i) for i in range(len(components))])
G = G.subgraph(components[i])
plt.figure(figsize=(15,15))
nx.draw_spring(G, 
                 node_color = [(G.degree(n)/float(d), 0, 0) for n in G.nodes()], #colors, 
                 with_labels = True, 
                 node_size = [5000*G.degree(n)/float(d) for n in G.nodes()],
                 edge_color='lightgray')        
```

    5784
    


![png](output_14_1.png)


### Question 5

How many nodes are in the largest (in terms of nodes) strongly connected component?

*This function should return an int*


```python
def answer_five():
        
    # Your Code Here
    G = answer_one()
    #nx.number_strongly_connected_components(G)    
    return max([len(x) for x in sorted(nx.strongly_connected_components(G))]) # Your Answer Here
#answer_five()
```

### Question 6

Using the NetworkX function strongly_connected_component_subgraphs, find the subgraph of nodes in a largest strongly connected component. 
Call this graph G_sc.

*This function should return a networkx MultiDiGraph named G_sc.*


```python
def answer_six():
        
    # Your Code Here
    G = answer_one()
    G_sc = max(nx.strongly_connected_component_subgraphs(G), key=len)
    return G_sc # Your Answer Here
#answer_six()
```

### Question 7

What is the average distance between nodes in G_sc?

*This function should return a float.*


```python
import seaborn as sns
def answer_seven():
        
    # Your Code Here
    G_sc = answer_six()
    sns.distplot(sum([x.values() for x in nx.shortest_path_length(G_sc).values()], []))
    return nx.average_shortest_path_length(G_sc) # Your Answer Here
answer_seven()
```

    5784
    




    1.6461587301587302




![png](output_20_2.png)


### Question 8

What is the largest possible distance between two employees in G_sc?

*This function should return an int.*


```python
def answer_eight():
        
    # Your Code Here
    G_sc = answer_six()  
    return nx.diameter(G_sc) # Your Answer Here
answer_eight()
```

    5784
    




    3




```python
from random import random
G_sc = answer_six()  
E = nx.eccentricity(G_sc)
m, n = max([(E[n], n) for n in E])
print(m, n)
mn = sorted([(E[n], n) for n in E], reverse=True)[:3]
print(mn)
#e = G.edges()
#ncolors = ['y' for _ in range(len(G.nodes())+1)]
#ecolors = ['lightgray' for _ in range(len(e))]
s = Digraph('emailnet', node_attr={'shape': 'plaintext'}, format='png',engine='sfdp') #,engine='circo') #engine='neato')
es = []
ns = []
for (m, n) in mn:
    paths = nx.shortest_path(G, n)
    done = False
    for x in paths:
        if len(paths[x]) == m+1:
            if not done:
                for i in range(m):
                    u, v = paths[x][i:i+2]
                    if not (u,v) in es:
                        es.append((u,v))
                        ns.append(u)
                        ns.append(v)
                done = True    
                #ncolors[int(u)] = 'red'
                #ecolors[e.index((u,v))] = 'red'
edict = defaultdict(int)
for (u,v) in G.edges():
    edict[u,v] += 1
s.attr('node', style='filled', color='red', shape='circle')
s.attr('edge', color='red')
for (u,v) in es:
    s.node(u)
    s.node(v)
    s.edge(u, v, label='', width='3')
s.attr('node', style='filled', color='lightblue2', shape='circle')
s.attr('edge', color='lightgray')
for (u,v) in edict:    
    if random() < 0.05:
        if not u in ns: s.node(u)
        if not v in ns: s.node(v)
        if not (u,v) in es:
            s.edge(u, v, '', style='dashed')
s.render('C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails_comp2', view=False)
Image(filename='C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails_comp2.png')#,width=200, height=2000)  
#plt.figure(figsize=(15,15))
#l = nx.random_layout(G)
#nx.draw_networkx_edges(G, pos=l, edge_color = ecolors)            
#nx.draw_networkx_nodes(G, pos=l, node_color = ncolors, with_labels = True, node_size = [5000*G.degree(n)/float(d) for n in G.nodes()]                 )
```

    5784
    (3, '97')
    [(3, '97'), (3, '134'), (3, '129')]
    




![png](output_23_1.png)



### Question 9

What is the set of nodes in G_sc with eccentricity equal to the diameter?

*This function should return a set of the node(s).*


```python
def answer_nine():
       
    # Your Code Here
    G_sc = answer_six()  
    return nx.periphery(G_sc)
answer_nine()
```

    5784
    




    ['134', '129', '97']



### Question 10

What is the set of node(s) in G_sc with eccentricity equal to the radius?

*This function should return a set of the node(s).*


```python
def answer_ten():
        
    # Your Code Here
    G_sc = answer_six()  
    return nx.center(G_sc)
answer_ten()
```

    5784
    




    ['38']




```python
from random import random
G_sc = answer_six()  
E = nx.eccentricity(G_sc)
m, n = min([(E[n], n) for n in E])
print(m, n)
s = Digraph('emailnet', node_attr={'shape': 'plaintext'}, format='png',engine='sfdp') #,engine='circo') #engine='neato')
es = []
ns = []
paths = nx.shortest_path(G, n)
done = False
for x in paths:
    if len(paths[x]) == m+1:
        for i in range(m):
            u, v = paths[x][i:i+2]
            if not (u,v) in es:
                es.append((u,v))
                ns.append(u)
                ns.append(v)
edict = defaultdict(int)
for (u,v) in G.edges():
    edict[u,v] += 1
s.attr('node', style='filled', color='red', shape='circle')
s.attr('edge', color='red')
for (u,v) in es:
    (sh, k, c) = ('doublecircle', 3, 'red') if u == '38' else ('circle', 2, 'lavenderblush')
    s.node(u,  **{'width':str(k), 'height':str(k), 'shape':sh, 'color':c, 'fontsize':str(100)})
    (sh, k, c) = ('doublecircle', 3, 'red') if v == '38' else ('circle', 2, 'lavenderblush')
    s.node(v,  **{'width':str(k), 'height':str(k), 'shape':sh, 'color':c, 'fontsize':str(100)})
    s.edge(u, v, label='', penwidth='5', arrowsize='3')
s.attr('node', style='filled', color='lightblue2', shape='circle')
s.attr('edge', color='lightgray')
for (u,v) in edict:    
    if random() < 0.1:
        if not u in ns: s.node(u)
        if not v in ns: s.node(v)
        if not (u,v) in es:
            s.edge(u, v, '', style='dashed')
s.render('C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails_comp3', view=False)
Image(filename='C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails_comp3.png')#,width=200, height=2000)  
#plt.figure(figsize=(15,15))
#l = nx.random_layout(G)
#nx.draw_networkx_edges(G, pos=l, edge_color = ecolors)            
#nx.draw_networkx_nodes(G, pos=l, node_color = ncolors, with_labels = True, node_size = [5000*G.degree(n)/float(d) for n in G.nodes()]                 )
```

    5784
    (1, '38')
    




![png](output_28_1.png)



### Question 11

Which node in G_sc has the most shortest paths to other nodes whose distance equal the diameter of G_sc?


How many of these paths are there?


*This function should return a tuple (name of node, number of paths).*


```python
def answer_eleven():
        
    # Your Code Here
    G_sc = answer_six()  
    d = nx.diameter(G_sc)
    lst = []
    for n in nx.periphery(G_sc):
        #print(n, nx.shortest_path_length(G_sc, n).values())
        lst.append((sum([1 for x in nx.shortest_path_length(G_sc, n).values() if x == d]), n))
    return max(lst)[::-1]    
answer_eleven()
```

    5784
    




    ('97', 63)




```python
G_sc = answer_six()  
E = nx.eccentricity(G_sc)
import seaborn as sns
sns.distplot(E.values())
```

    5784
    




    <matplotlib.axes._subplots.AxesSubplot at 0x2396cba8>




![png](output_31_2.png)



```python
from random import random
G_sc = answer_six()  
E = nx.eccentricity(G_sc)
m, n = max([(E[n], n) for n in E])
print(m, n)
#e = G.edges()
#ncolors = ['y' for _ in range(len(G.nodes())+1)]
#ecolors = ['lightgray' for _ in range(len(e))]
s = Digraph('emailnet', node_attr={'shape': 'plaintext'}, format='png',engine='sfdp') #,engine='circo') #engine='neato')
es = []
ns = []
paths = nx.shortest_path(G, n)
pc, done = 0, False
for x in paths:
    if len(paths[x]) == m+1 and not done:
        for i in range(m):
            u, v = paths[x][i:i+2]
            if not (u,v) in es:
                es.append((u,v))
                ns.append(u)
                ns.append(v)
        pc += 1
        if pc == 5: done = True
edict = defaultdict(int)
for (u,v) in G.edges():
    edict[u,v] += 1
s.attr('node', style='filled', color='red', shape='circle')
s.attr('edge', color='red')
for (u,v) in es:
    (sh, k, c) = ('doublecircle', 3, 'red') if u == '97' else ('circle', 2, 'gold')
    s.node(u,  **{'width':str(k), 'height':str(k), 'shape':sh, 'color':c, 'fontsize':str(50)})
    (sh, k, c) = ('doublecircle', 3, 'red') if v == '97' else ('circle', 2, 'gold')
    s.node(v,  **{'width':str(k), 'height':str(k), 'shape':sh, 'color':c, 'fontsize':str(50)})
    s.edge(u, v, label='', penwidth='5', arrowsize='3')
s.attr('node', style='filled', color='lightblue2', shape='circle')
s.attr('edge', color='lightgray')
for (u,v) in edict:    
    if random() < 0.2:
        if not u in ns: s.node(u)
        if not v in ns: s.node(v)
        if not (u,v) in es:
            s.edge(u, v, '', style='dashed')
s.render('C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails_comp2', view=False)
Image(filename='C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails_comp2.png')#,width=200, height=2000)  
```

    5784
    (3, '97')
    




![png](output_32_1.png)



### Question 12

Suppose you want to prevent communication from flowing to the node that you found in the previous question from any node in the center of G_sc, what is the smallest number of nodes you would need to remove from the graph (you're not allowed to remove the node from the previous question or the center nodes)? 

*This function should return an integer.*


```python
def answer_twelve():
        
    # Your Code Here
    G_sc = answer_six()  
    center_node = answer_ten()[0]
    target_node = answer_eleven()[0]
    return len(nx.minimum_node_cut(G_sc, center_node, target_node)) # Your Answer Here
answer_twelve()
```

    5784
    5784
    5784
    




    5




```python
from random import random
G_sc = answer_six()  
center_node = answer_ten()[0]
target_node = answer_eleven()[0]
cns = nx.minimum_node_cut(G_sc, center_node, target_node)
s = Digraph('emailnet', node_attr={'shape': 'plaintext'}, format='png')#,engine='sfdp') #,engine='circo') #engine='neato')
es = []
ns = []
for n in cns:
    x = nx.shortest_path(G, center_node, n)
    for i in range(len(x)-1):
        u, v = x[i:i+2]
        if not (u,v) in es:
            es.append((u,v))
            ns.append(u)
            ns.append(v)
    x = nx.shortest_path(G, n, target_node)
    for i in range(len(x)-1):
        u, v = x[i:i+2]
        if not (u,v) in es:
            es.append((u,v))
            ns.append(u)
            ns.append(v)

edict = defaultdict(int)
for (u,v) in G.edges():
    edict[u,v] += 1
s.attr('node', style='filled', color='red', shape='circle')
s.attr('edge', color='red')
for (u,v) in es:
    (sh, k, c) = ('doublecircle', 2, 'red') if u in [center_node, target_node] else ('circle', 1.5, 'palegoldenrod')
    s.node(u,  **{'width':str(k), 'height':str(k), 'shape':sh, 'color':c, 'fontsize':str(20)})
    (sh, k, c) = ('doublecircle', 2, 'red') if v in [center_node, target_node] else ('circle', 1.5, 'palegoldenrod')
    s.node(v,  **{'width':str(k), 'height':str(k), 'shape':sh, 'color':c, 'fontsize':str(20)})
    s.edge(u, v, label='', penwidth='3', arrowsize='2')
s.attr('node', style='filled', color='lightblue2', shape='circle')
s.attr('edge', color='lightgray')
for (u,v) in edict:    
    if not u in ns: s.node(u)
    if not v in ns: s.node(v)
    if random() < 0.1:
        if not (u,v) in es:
            s.edge(u, v, '', style='dashed')
s.render('C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails_comp6', view=False)
```

    5784
    5784
    5784
    


```python
Image(filename='C:\courses\Coursera\Past\Specialization-UMich Applied Data Science with Python\Social Network Analysis Python\Week2\emails_comp6.png')#,width=200, height=2000)  
```




![png](output_36_0.png)



### Question 13

Construct an undirected graph G_un using G_sc (you can ignore the attributes).

*This function should return a networkx Graph.*


```python
def answer_thirteen():
        
    # Your Code Here
    G_sc = answer_six()  
    G_un = nx.Graph(G_sc.to_undirected())  # multigraph to graph
    #print(type(G_un))
    return G_un # Your Answer Here
G = answer_thirteen()
d = max([G.degree(n) for n in G.nodes()])
plt.figure(figsize=(15,15))
nx.draw_spring(G, 
                 node_color = [(G.degree(n)/float(d), (G.degree(n)/float(d))**2, 0.1) for n in G.nodes()], #colors, 
                 with_labels = True, 
                 node_size = [5000*G.degree(n)/float(d) for n in G.nodes()],
                 edge_color='lightgray')
```

    5784
    


![png](output_38_1.png)


### Question 14

What is the transitivity and average clustering coefficient of graph G_un?

*This function should return a tuple (transitivity, avg clustering).*


```python
def answer_fourteen():
        
    # Your Code Here
    G_un = answer_thirteen()    
    return (nx.transitivity(G_un), nx.average_clustering(G_un)) # Your Answer Here
answer_fourteen()
G = answer_thirteen()
cs = nx.clustering(G)
#cs = [cs[str(n)] for n in sorted(map(int, cs.keys()))]
d = max(cs.values())
plt.figure(figsize=(15,15))
nx.draw_spring(G, 
                 node_color = [(cs[n]/float(d), (cs[n]/float(d))**2, 0.5) for n in G.nodes()], #colors, 
                 with_labels = True, 
                 node_size = [5000*cs[n]/float(d) for n in G.nodes()],
                 edge_color='lightgray')
```

    5784
    5784
    


![png](output_40_1.png)



```python
G_un = answer_thirteen()    
cs = nx.clustering(G_un)
import seaborn as sns
sns.distplot(cs.values(), color='green')
```

    5784
    




    <matplotlib.axes._subplots.AxesSubplot at 0x1ee65278>




![png](output_41_2.png)

